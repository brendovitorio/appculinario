import axios from 'axios';
import { jsPDF } from 'jspdf';

async function fetchRecipes(type = '', generatePDF = false) {
    let url = 'COLOQUE USA API QUE PUXA TODAS AS RECEITAS';
    if (type) {
        url = `COLOQUE USA API Q PUXA POR TIPO (DOCE, SAlGADO, AGRIDOCE, etc)`;
    }    

    try {
        const response = await axios.get(url);
        const recipes = response.data;

        const recipeList = document.getElementById('recipe-list');
        recipeList.innerHTML = ''; 

        if (recipes && recipes.length > 0) {
            recipes.forEach((recipe) => {
                const recipeItem = document.createElement('li');
                recipeItem.classList.add('recipe-item');
                recipeItem.innerHTML = `<h3>${recipe.title}</h3><p>${recipe.description}</p>`;
                recipeList.appendChild(recipeItem);
            });

            if (generatePDF) {
                generateRecipePDF(recipes);
            }
        } else {
            recipeList.innerHTML = `<li>Nenhuma receita encontrada</li>`;
        } 
    } catch (error) {
        console.error('Erro ao buscar receitas:', error);
    }
}

function generateRecipePDF(recipes) {
    const doc = new jsPDF();
    let y = 10; // Posição inicial no PDF

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('Receitas', 10, y);
    y += 10;

    recipes.forEach((recipe, index) => {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(12);
        doc.text(`${index + 1}. ${recipe.title}`, 10, y);
        y += 6;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        let descriptionLines = doc.splitTextToSize(recipe.description, 180);
        doc.text(descriptionLines, 10, y);
        y += descriptionLines.length * 6 + 4; 

        if (y > 270) { // Se estiver perto do final da página, cria uma nova página
            doc.addPage();
            y = 10;
        }
    });

    doc.save('receitas.pdf');
}

// Botões para carregar receitas
document.getElementById('btn-todas').addEventListener('click', () => fetchRecipes());
document.getElementById('btn-doce').addEventListener('click', () => fetchRecipes('doce'));
document.getElementById('btn-salgado').addEventListener('click', () => fetchRecipes('salgado'));
document.getElementById('btn-agridoce').addEventListener('click', () => fetchRecipes('agridoce'));

// Botão para gerar PDF
document.getElementById('btn-pdf').addEventListener('click', () => fetchRecipes('', true));
